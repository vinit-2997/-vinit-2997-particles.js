A Pen created at CodePen.io. You can find this one at https://codepen.io/ettrics/pen/WRbGRN.

 Navigation bar that sticks as you scroll, animating a slider which indicates the page section you are currently looking at. Written with SCSS, Javascript, and JQuery.