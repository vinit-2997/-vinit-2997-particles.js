A Pen created at CodePen.io. You can find this one at https://codepen.io/marlenesco/pen/NqOozj.

 Responsive material card based on Google Material Color palette in a bootstrap grid.